# Password reset email

Participants and facilitators can select **Forgot your password?** on their login view, or open `/reset-password.html` directly. The email links to that page with a one-use token in the URL fragment. The browser removes the fragment immediately and sends the token only in the password-change POST body.

Configure these secrets on the existing Render service, then redeploy:

- `BREVO_API_KEY`: a Brevo transactional email API key (not an SMTP key).
- `TRUSTBUILDER_MAIL_FROM`: an email address verified as a sender in that Brevo account.
- `TRUSTBUILDER_PUBLIC_ORIGIN`: the HTTPS app origin, if `RENDER_EXTERNAL_URL` is unavailable. Never use a request-supplied host for email links.

No plaintext password or token is stored in PostgreSQL. Reset tokens are SHA-256 hashed, expire in 30 minutes, and are consumed atomically with the salted-scrypt password update and session revocation. A confirmation email is sent after a successful change. Accounts retain their existing roles. Administrator accounts are deliberately excluded from this participant/facilitator flow.

To limit email abuse, requests are limited in PostgreSQL to one per normalized email per 15 minutes and 100 per application per day. Unknown emails and inactive/administrator accounts get the same response and do not receive email. Email-provider failures are logged without addresses, tokens or provider response bodies. Missing email configuration returns a visible unavailable message, never a fake delivery claim.

Before enabling for users: verify the sender, set the secrets, request a reset for a controlled participant and facilitator Gmail inbox, confirm delivery, change the password, confirm old passwords and sessions fail, and confirm links cannot be reused. Domain authentication is recommended for reliable delivery.

UI reference: the existing TrustBuilder login page owns layout, typography, colors, button and field treatments. Refero's craft-details guide informs explicit labels, password-manager autocomplete, accessible status/errors and submission states. No new visual theme is introduced.

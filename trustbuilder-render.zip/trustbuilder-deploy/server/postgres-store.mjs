import pg from "pg";

// Keep the existing application document contract while moving durable state
// off Render's ephemeral filesystem. Only one application instance is deployed.
export class PostgresStore {
  constructor({ connectionString, seed }) {
    this.pool = new pg.Pool({ connectionString, max: 3, connectionTimeoutMillis: 15000, idleTimeoutMillis: 10000 });
    this.seed = seed;
    this.queue = Promise.resolve();
  }
  async initialize() {
    await this.pool.query("CREATE TABLE IF NOT EXISTS trustbuilder_state (id integer PRIMARY KEY CHECK (id = 1), document jsonb NOT NULL)");
    await this.pool.query("INSERT INTO trustbuilder_state(id, document) VALUES (1, $1::jsonb) ON CONFLICT (id) DO NOTHING", [JSON.stringify(this.seed())]);
    await this.pool.query("CREATE TABLE IF NOT EXISTS trustbuilder_auth_sessions (token_hash text PRIMARY KEY, user_id text NOT NULL, expires_at bigint NOT NULL)");
    return this;
  }
  async read() {
    const { rows } = await this.pool.query("SELECT document FROM trustbuilder_state WHERE id = 1");
    return structuredClone(rows[0].document);
  }
  async write(data) {
    const operation = async () => {
      await this.pool.query("UPDATE trustbuilder_state SET document = $1::jsonb WHERE id = 1", [JSON.stringify(data)]);
      return structuredClone(data);
    };
    this.queue = this.queue.then(operation, operation);
    return this.queue;
  }
  async transaction(mutator) {
    const operation = async () => {
      const client = await this.pool.connect();
      try {
        await client.query("BEGIN");
        const { rows } = await client.query("SELECT document FROM trustbuilder_state WHERE id = 1 FOR UPDATE");
        const current = rows[0].document;
        const result = await mutator(current);
        await client.query("UPDATE trustbuilder_state SET document = $1::jsonb WHERE id = 1", [JSON.stringify(result?.data || current)]);
        await client.query("COMMIT");
        return result?.result;
      } catch (error) {
        await client.query("ROLLBACK");
        throw error;
      } finally { client.release(); }
    };
    this.queue = this.queue.then(operation, operation);
    return this.queue;
  }
  async saveSession(hash, userId, expiresAt) {
    await this.pool.query("DELETE FROM trustbuilder_auth_sessions WHERE expires_at <= $1", [Date.now()]);
    await this.pool.query("INSERT INTO trustbuilder_auth_sessions(token_hash, user_id, expires_at) VALUES ($1, $2, $3)", [hash, userId, expiresAt]);
  }
  async findSession(hash) {
    const { rows } = await this.pool.query("SELECT user_id FROM trustbuilder_auth_sessions WHERE token_hash = $1 AND expires_at > $2", [hash, Date.now()]);
    if (!rows.length) return null;
    const data = await this.read();
    return data.users.find(user => user.id === rows[0].user_id && user.status === "active") || null;
  }
  async deleteSession(hash) {
    await this.pool.query("DELETE FROM trustbuilder_auth_sessions WHERE token_hash = $1", [hash]);
  }
}

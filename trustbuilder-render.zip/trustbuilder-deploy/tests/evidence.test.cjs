const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs');
const d = require('../domain.js');
const accepted = text => ({ id: 'turn-1', role: 'participant', accepted: true, text });
test('canonical framework has exact six and seven names', () => {
  assert.deepEqual(d.IMPACT_R.map(x=>x.name), ['Interpret the Context','Make Outcomes Visible','Position Your POV','Adapt Communication','Commit with Ownership','Trust through Consistency','Restraint']);
  assert.deepEqual(d.CAPABILITIES, ['Active Listening','Adaptive Thinking','Judgement & Restraint','Constructive Hypothesis Building','Professional Speech Excellence','Language Accuracy']);
});
test('empty and rejected evidence never creates neutral scores',()=>{
  for(const turns of [[], [{...accepted('I understand the adoption concern for operations.'),accepted:false}]]) {
    const r=d.assessEvidence(turns);assert.equal(r.capabilityScores.length,6);assert.equal(r.impactScores.length,7);
    assert.ok([...r.capabilityScores,...r.impactScores].every(m=>m.score===null && m.evidenceStatus==='not_observed'));
  }
});
test('combined observable behaviours have attributable quotes; isolated keywords do not',()=>{
  const r=d.assessEvidence([accepted('I understand the adoption concern for operations. I will validate the evidence and update you by Friday.')]);
  assert.equal(r.capabilityScores[0].score,4);assert.equal(r.capabilityScores[0].evidenceTurnId,'turn-1');
  assert.equal(r.capabilityScores[1].score,null);assert.equal(r.capabilityScores[4].score,null);assert.equal(r.impactScores[4].score,4);
  assert.ok(d.assessEvidence([accepted('evidence impact recommendation ownership')]).impactScores.every(m=>m.score===null));
});
test('voice and text share scoring, and transcript does not invent delivery measures',()=>{
  const t=accepted('I recommend validation because adoption evidence is incomplete.');
  const a=d.assessEvidence([{...t,source:'voice',audioReference:{id:'clip'}}]), b=d.assessEvidence([{...t,source:'text'}]);
  assert.deepEqual(a.capabilityScores,b.capabilityScores);assert.deepEqual(a.impactScores,b.impactScores);assert.equal(a.capabilityScores[4].score,null);
});
test('mode changes hidden context and stakeholder fallback; no coaching is spoken',()=>{
  const messages=[];
  for(const mode of ['HUNT','FARM','MINE']){
    const context=d.buildConversationContext({template:d.DEFAULT_TEMPLATE,scenario:d.DEFAULT_SCENARIO,mode});
    assert.equal(context.influenceMode.name,mode);
    const output=d.fallbackAIMessage({decision:'FOLLOW_UP',mode});messages.push(output.message);
    assert.doesNotMatch(output.message,/your score|great answer|well done|rubric/i);
  }
  assert.equal(new Set(messages).size,3);
});
test('active scoring files contain no incorrect IMPACT labels',()=>{
  for(const file of ['../domain.js','../server.mjs','../simulation.js','../app.js']){
    const text=fs.readFileSync(require.resolve(file),'utf8');
    assert.doesNotMatch(text,/\["[IMPACT R]", "(?:Insight|Message|Presence|Adaptability|Commerciality|Trust|Relationship\s*\/\s*Result)"\]/);
  }
});
